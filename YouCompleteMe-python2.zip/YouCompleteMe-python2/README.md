this is a compiled youcompleteme for windows
I compile this use Visual Studio 2015, on windows 10 x64, python version is 2.7
I download vim 8.0 from https://bintray.com/micbou/generic/vim
